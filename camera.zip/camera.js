var tessel = require("tessel");
var app    = require("express")();
var http   = require("http").Server(app);
var io     = require("socket.io")(http);
var os     = require("os");
var fs     = require("fs");
var path   = require("path");
var av     = require("tessel-av");
var port   = 8000;
var camera = new av.Camera();

http.listen(port, function(){
  tessel.led[2].on();
  setInterval(function() { tessel.led[2].toggle(); }, 500);
  console.log("Server running at http://192.168.1.101:" + port);
});

app.get("/", function(req, res){
  res.sendFile(__dirname + "/index.html");
});

app.get("/stream", function(req, res){
  res.redirect(camera.url);
});

app.get("/image/:filename/:filetype", function(req, res){
  var img = fs.readFileSync(path.join(__dirname, req.params.filename + "." + req.params.filetype));
  res.writeHead(200, {"content-Type": "image/" + req.params.filetype});
  res.end(img, "binary");
});

io.on("connection", function(socket){
  socket.on("shot", function() {
	tessel.led[3].on();
	socket.emit("shot", camera.frame.toString("base64"));
	setTimeout(function() { tessel.led[3].off(); }, 200);
  });
});

